function setWeight(weight, context) {
  addAction({
    type: "SET_WEIGHT",
    payload: weight,
  }, context);
}

function setHeight(height, context) {
  addAction({
    type: "SET_HEIGHT",
    payload: height,
  }, context);
}

function calculateBmi(context) {
  addAction({
    type: "CALCULATE_BMI",
  }, context);
}

function resetState(context) {
  addAction({
    type: "RESET",
  }, context);
}

function addNote(note, context) {
    addAction({
        type: "add_note",
        note: note
    }, context);
}

// Helper function to dispatch actions
//function addAction(action, context) {
  //context.dispatchAssistantAction(action);
//}

